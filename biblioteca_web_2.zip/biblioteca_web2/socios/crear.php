<?php
$base = '../';
require '../config/conexion.php';
$s = ['nombre' => '', 'dni' => '', 'email' => '', 'telefono' => ''];
$usuario = '';
$tiene_cuenta = false;
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $s = array_merge($s, $_POST);
    $usuario = trim($_POST['usuario'] ?? '');
    $clave = $_POST['clave'] ?? '';
    if (trim($s['nombre']) === '' || trim($s['dni']) === '') {
        $err = 'Nombre y DNI son obligatorios.';
    } elseif ($usuario !== '' && $clave === '') {
        $err = 'Si cargás un usuario, tenés que ponerle una clave.';
    } elseif ($usuario === '' && $clave !== '') {
        $err = 'Escribí el usuario para esa clave.';
    } else {
        try {
            $pdo->beginTransaction();
            $pdo->prepare('INSERT INTO socios (nombre, dni, email, telefono) VALUES (?,?,?,?)')
                ->execute([trim($s['nombre']), trim($s['dni']), $s['email'], $s['telefono']]);
            if ($usuario !== '') {
                $id_socio = $pdo->lastInsertId();
                $pdo->prepare("INSERT INTO usuarios (usuario, clave, rol, id_socio) VALUES (?, ?, 'cliente', ?)")
                    ->execute([$usuario, password_hash($clave, PASSWORD_DEFAULT), $id_socio]);
            }
            $pdo->commit();
            flash('Socio agregado correctamente.');
            header('Location: index.php');
            exit;
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $err = str_contains($e->getMessage(), 'usuario')
                ? 'Ese nombre de usuario ya está en uso.'
                : 'Ya existe un socio con ese DNI.';
        }
    }
}
include '../includes/header.php';
?>
<h2>Nuevo socio</h2>
<?php include 'form.php'; ?>
<?php include '../includes/footer.php'; ?>