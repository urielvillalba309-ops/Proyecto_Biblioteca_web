<?php
require '../config/conexion.php';
try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $pdo->prepare('DELETE FROM socios WHERE id = ?')->execute([(int)$_POST['id']]);
        flash('Socio eliminado.');
    }
    header('Location: index.php');
} catch (PDOException $e) {
    header('Location: index.php?error=1');
}