<?php
$base = '../';
require '../config/conexion.php';
$q = trim($_GET['q'] ?? '');
$st = $pdo->prepare('SELECT s.*, u.usuario FROM socios s LEFT JOIN usuarios u ON u.id_socio = s.id
    WHERE s.nombre LIKE ? OR s.dni LIKE ? ORDER BY s.nombre');
$st->execute(["%$q%", "%$q%"]);
$socios = $st->fetchAll();
include '../includes/header.php';
?>
<h2>Socios</h2>
<?php if (isset($_GET['error'])): ?><p class="msg error">No se puede eliminar: el socio tiene préstamos asociados.</p><?php endif; ?>
<div class="barra">
  <form method="get"><input name="q" placeholder="Buscar nombre o DNI" value="<?= e($q) ?>"><button>Buscar</button></form>
  <a class="btn" href="crear.php">+ Nuevo socio</a>
</div>
<table>
    <tr><th>Nombre</th><th>DNI</th><th>Email</th><th>Teléfono</th><th>Usuario</th><th></th></tr>
  <?php foreach ($socios as $s): ?>
  <tr>
    <td><?= e($s['nombre']) ?></td><td><?= e($s['dni']) ?></td><td><?= e($s['email']) ?></td><td><?= e($s['telefono']) ?></td>
    <td><?= $s['usuario'] ? e($s['usuario']) : '<small>—</small>' ?></td>   <!-- esta es la nueva -->
    <td class="acc">
    <td class="acc">
      <a class="btn sm" href="editar.php?id=<?= $s['id'] ?>">Editar</a>
      <form method="post" action="eliminar.php" onsubmit="return confirm('¿Eliminar este socio?')">
        <input type="hidden" name="id" value="<?= $s['id'] ?>"><button class="sm rojo">Eliminar</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
<?php include '../includes/footer.php'; ?>
