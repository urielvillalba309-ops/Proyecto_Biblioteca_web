<?php
// variables que llegan desde crear.php / editar.php
$s            = $s ?? ['nombre' => '', 'dni' => '', 'email' => '', 'telefono' => ''];
$usuario      = $usuario ?? '';
$tiene_cuenta = $tiene_cuenta ?? false;
$err          = $err ?? '';
?>
<?php if ($err): ?><p class="msg error"><?= e($err) ?></p><?php endif; ?>
<form method="post" class="form">
  <label>Nombre completo <input name="nombre" value="<?= e($s['nombre']) ?>" required></label>
  <label>DNI <input name="dni" value="<?= e($s['dni']) ?>" required></label>
  <label>Email <input type="email" name="email" value="<?= e($s['email']) ?>"></label>
  <label>Teléfono <input name="telefono" value="<?= e($s['telefono']) ?>"></label>

  <hr>
  <p><b>Acceso a la web (opcional)</b></p>
  <label>Usuario <input name="usuario" value="<?= e($usuario) ?>" <?= $tiene_cuenta ? 'readonly' : '' ?>></label>
  <label>Clave <input type="password" name="clave" placeholder="<?= $tiene_cuenta ? 'Dejar vacío para no cambiarla' : '' ?>"></label>

  <button>Guardar</button> <a href="index.php">Cancelar</a>
</form>