<?php
$base = '../';
require '../config/conexion.php';
$id = (int)($_GET['id'] ?? 0);
$st = $pdo->prepare('SELECT * FROM socios WHERE id = ?');
$st->execute([$id]);
$s = $st->fetch();
if (!$s) { header('Location: index.php'); exit; }

// ¿este socio ya tiene cuenta?
$st = $pdo->prepare('SELECT * FROM usuarios WHERE id_socio = ?');
$st->execute([$id]);
$cuenta = $st->fetch();
$tiene_cuenta = (bool)$cuenta;
$usuario = $cuenta['usuario'] ?? '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $s = array_merge($s, $_POST);
    $clave = $_POST['clave'] ?? '';
    if (!$tiene_cuenta) $usuario = trim($_POST['usuario'] ?? '');

    if (trim($s['nombre']) === '' || trim($s['dni']) === '') {
        $err = 'Nombre y DNI son obligatorios.';
    } elseif (!$tiene_cuenta && $usuario !== '' && $clave === '') {
        $err = 'Si cargás un usuario, tenés que ponerle una clave.';
    } elseif (!$tiene_cuenta && $usuario === '' && $clave !== '') {
        $err = 'Escribí el usuario para esa clave.';
    } else {
        try {
            $pdo->beginTransaction();
            $pdo->prepare('UPDATE socios SET nombre=?, dni=?, email=?, telefono=? WHERE id=?')
                ->execute([trim($s['nombre']), trim($s['dni']), $s['email'], $s['telefono'], $id]);
            if ($tiene_cuenta && $clave !== '') {
                // cambia la clave de la cuenta existente
                $pdo->prepare('UPDATE usuarios SET clave = ? WHERE id = ?')
                    ->execute([password_hash($clave, PASSWORD_DEFAULT), $cuenta['id']]);
            } elseif (!$tiene_cuenta && $usuario !== '') {
                // le crea la cuenta al socio
                $pdo->prepare("INSERT INTO usuarios (usuario, clave, rol, id_socio) VALUES (?, ?, 'cliente', ?)")
                    ->execute([$usuario, password_hash($clave, PASSWORD_DEFAULT), $id]);
            }
            $pdo->commit();
            flash('Socio actualizado correctamente.');
            header('Location: index.php');
            exit;
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $err = str_contains($e->getMessage(), 'usuario')
                ? 'Ese nombre de usuario ya está en uso.'
                : 'Ya existe un socio con ese DNI.';
        }
    }
}
include '../includes/header.php';
?>
<h2>Editar socio</h2>
<?php include 'form.php'; ?>
<?php include '../includes/footer.php'; ?>