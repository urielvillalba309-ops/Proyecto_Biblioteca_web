<?php
$base = '';
require 'config/conexion.php';
$n = fn($sql) => $pdo->query($sql)->fetchColumn();

$libros   = $n('SELECT COUNT(*) FROM libros');
$socios   = $n('SELECT COUNT(*) FROM socios');
$activos  = $n('SELECT COUNT(*) FROM prestamos WHERE fecha_devolucion IS NULL');
$vencidos = $n('SELECT COUNT(*) FROM prestamos WHERE fecha_devolucion IS NULL AND fecha_prestamo < DATE_SUB(CURDATE(), INTERVAL 7 DAY)');

$ultimos = $pdo->query('SELECT p.*, l.titulo, s.nombre AS socio FROM prestamos p
    JOIN libros l ON l.id = p.id_libro JOIN socios s ON s.id = p.id_socio
    ORDER BY p.id DESC LIMIT 5')->fetchAll();
$pocos = $pdo->query('SELECT titulo, autor, stock FROM libros WHERE stock <= 1 ORDER BY stock, titulo LIMIT 5')->fetchAll();

include 'includes/header.php';
?>
<h2>Panel</h2>

<div class="cards">
  <a class="card" href="libros/index.php"><span class="ico c1">📖</span><div><b><?= $libros ?></b><small>Libros</small></div></a>
  <a class="card" href="socios/index.php"><span class="ico c2">👥</span><div><b><?= $socios ?></b><small>Socios</small></div></a>
  <a class="card" href="prestamos/index.php"><span class="ico c3">🔄</span><div><b><?= $activos ?></b><small>Préstamos activos</small></div></a>
  <a class="card" href="prestamos/index.php"><span class="ico c4">⏰</span><div><b><?= $vencidos ?></b><small>Vencidos (+7 días)</small></div></a>
</div>

<div class="rapido">
  <a class="btn" href="prestamos/crear.php">+ Nuevo préstamo</a>
  <a class="btn" href="libros/crear.php">+ Nuevo libro</a>
  <a class="btn" href="socios/crear.php">+ Nuevo socio</a>
</div>

<div class="grid2">
  <section>
    <h3>Últimos préstamos</h3>
    <table>
      <tr><th>Libro</th><th>Socio</th><th>Estado</th></tr>
      <?php foreach ($ultimos as $p): ?>
      <tr>
        <td><?= e($p['titulo']) ?></td><td><?= e($p['socio']) ?></td>
        <td><?= $p['fecha_devolucion'] ? '<span class="ok">Devuelto</span>' : '<span class="pend">Pendiente</span>' ?></td>
      </tr>
      <?php endforeach; ?>
      <?php if (!$ultimos): ?><tr><td colspan="3">Todavía no hay préstamos.</td></tr><?php endif; ?>
    </table>
  </section>
  <section>
    <h3>Libros con poco stock</h3>
    <table>
      <tr><th>Título</th><th>Autor</th><th>Stock</th></tr>
      <?php foreach ($pocos as $l): ?>
      <tr>
        <td><?= e($l['titulo']) ?></td><td><?= e($l['autor']) ?></td>
        <td><span class="<?= $l['stock'] == 0 ? 'pend' : 'warn' ?>"><?= e($l['stock']) ?></span></td>
      </tr>
      <?php endforeach; ?>
      <?php if (!$pocos): ?><tr><td colspan="3">Todo el stock está bien.</td></tr><?php endif; ?>
    </table>
  </section>
</div>
<?php include 'includes/footer.php'; ?>
