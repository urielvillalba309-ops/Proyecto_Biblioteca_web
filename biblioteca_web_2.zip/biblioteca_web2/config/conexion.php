<?php
// Ajustá usuario/clave según tu XAMPP/WAMP
$pdo = new PDO('mysql:host=localhost;dbname=biblioteca_web2;charset=utf8mb4', 'root', '', [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// ---- Sesión y roles ----
if (session_status() === PHP_SESSION_NONE) session_start();

$rol        = $_SESSION['rol'] ?? '';
$es_admin   = $rol === 'admin';
$es_cliente = $rol === 'cliente';

// ruta para volver a la raíz (las carpetas de módulos están un nivel abajo)
$carpeta = basename(dirname($_SERVER['SCRIPT_NAME']));
$sub     = in_array($carpeta, ['libros', 'socios', 'prestamos', 'categorias', 'solicitudes']);
$ruta    = $sub ? '../' : '';

// ---- Guardia ----
// $publica = true      -> cualquiera entra (login, catálogo)
// $solo_cliente = true -> solo clientes
// sin ninguna          -> solo admin
if (empty($publica)) {
    if (!empty($solo_cliente)) {
        if (!$es_cliente) {
            header('Location: ' . $ruta . ($es_admin ? 'index.php' : 'login.php'));
            exit;
        }
    } elseif (!$es_admin) {
        header('Location: ' . $ruta . ($es_cliente ? 'libros/index.php' : 'login.php'));
        exit;
    }
}

// ---- Mensajes flash (se muestran una sola vez) ----
function flash($msg, $tipo = 'exito') { $_SESSION['flash'] = [$msg, $tipo]; }
function mostrar_flash() {
    if (!empty($_SESSION['flash'])) {
        [$msg, $tipo] = $_SESSION['flash'];
        echo '<p class="msg ' . e($tipo) . '">' . e($msg) . '</p>';
        unset($_SESSION['flash']);
    }
}