<?php
$base = '../';
require '../config/conexion.php';
$prestamos = $pdo->query('SELECT p.*, l.titulo, s.nombre AS socio FROM prestamos p
    JOIN libros l ON l.id = p.id_libro JOIN socios s ON s.id = p.id_socio
    ORDER BY p.fecha_devolucion IS NULL DESC, p.fecha_prestamo DESC')->fetchAll();
include '../includes/header.php';
?>
<h2>Préstamos</h2>
<div class="barra"><span></span><a class="btn" href="crear.php">+ Nuevo préstamo</a></div>
<table>
  <tr><th>Libro</th><th>Socio</th><th>Prestado</th><th>Estado</th><th></th></tr>
  <?php foreach ($prestamos as $p): ?>
  <tr>
    <td><?= e($p['titulo']) ?></td><td><?= e($p['socio']) ?></td><td><?= e($p['fecha_prestamo']) ?></td>
    <td><?= $p['fecha_devolucion'] ? '<span class="ok">Devuelto ' . e($p['fecha_devolucion']) . '</span>' : '<span class="pend">Pendiente</span>' ?></td>
    <td class="acc">
      <?php if (!$p['fecha_devolucion']): ?>
      <form method="post" action="devolver.php"><input type="hidden" name="id" value="<?= $p['id'] ?>"><button class="sm verde">Devolver</button></form>
      <?php endif; ?>
      <form method="post" action="eliminar.php" onsubmit="return confirm('¿Eliminar este préstamo?')">
        <input type="hidden" name="id" value="<?= $p['id'] ?>"><button class="sm rojo">Eliminar</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
<?php include '../includes/footer.php'; ?>
