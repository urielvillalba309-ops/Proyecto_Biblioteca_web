<?php
require '../config/conexion.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)$_POST['id'];
    $pdo->beginTransaction();
    $u = $pdo->prepare('UPDATE prestamos SET fecha_devolucion = CURDATE() WHERE id = ? AND fecha_devolucion IS NULL');
    $u->execute([$id]);
    if ($u->rowCount()) {
        $pdo->prepare('UPDATE libros SET stock = stock + 1 WHERE id = (SELECT id_libro FROM prestamos WHERE id = ?)')->execute([$id]);
        flash('Devolución registrada. El libro vuelve a estar disponible.');
    }
    $pdo->commit();
}
header('Location: index.php');