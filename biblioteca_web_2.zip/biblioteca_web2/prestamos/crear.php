<?php
$base = '../';
require '../config/conexion.php';
$libros = $pdo->query('SELECT id, titulo, stock FROM libros WHERE stock > 0 ORDER BY titulo')->fetchAll();
$socios = $pdo->query('SELECT id, nombre, dni FROM socios ORDER BY nombre')->fetchAll();
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lb = (int)($_POST['id_libro'] ?? 0);
    $so = (int)($_POST['id_socio'] ?? 0);
    if (!$lb || !$so) {
        $err = 'Elegí un libro y un socio.';
    } else {
        $pdo->beginTransaction();
        $u = $pdo->prepare('UPDATE libros SET stock = stock - 1 WHERE id = ? AND stock > 0');
        $u->execute([$lb]);
        if ($u->rowCount()) {
            $pdo->prepare('INSERT INTO prestamos (id_libro, id_socio, fecha_prestamo) VALUES (?,?,CURDATE())')->execute([$lb, $so]);
            $pdo->commit();
            flash('Préstamo registrado correctamente.');
            header('Location: index.php');
            exit;
        }
        $pdo->rollBack();
        $err = 'El libro no tiene stock.';
    }
}
include '../includes/header.php';
?>
<h2>Nuevo préstamo</h2>
<?php if ($err): ?><p class="msg error"><?= e($err) ?></p><?php endif; ?>
<form method="post" class="form">
  <label>Libro
    <select name="id_libro" required>
      <option value="">Elegí...</option>
      <?php foreach ($libros as $l): ?><option value="<?= $l['id'] ?>"><?= e($l['titulo']) ?> (stock: <?= $l['stock'] ?>)</option><?php endforeach; ?>
    </select>
  </label>
  <label>Socio
    <select name="id_socio" required>
      <option value="">Elegí...</option>
      <?php foreach ($socios as $s): ?><option value="<?= $s['id'] ?>"><?= e($s['nombre']) ?> - <?= e($s['dni']) ?></option><?php endforeach; ?>
    </select>
  </label>
  <button>Registrar préstamo</button> <a href="index.php">Cancelar</a>
</form>
<?php include '../includes/footer.php'; ?>
