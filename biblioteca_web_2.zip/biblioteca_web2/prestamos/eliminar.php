<?php
require '../config/conexion.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)$_POST['id'];
    $pdo->beginTransaction();
    // si todavía no estaba devuelto, se repone el stock antes de borrar
    $pdo->prepare('UPDATE libros SET stock = stock + 1 WHERE id = (SELECT id_libro FROM prestamos WHERE id = ? AND fecha_devolucion IS NULL)')->execute([$id]);
    $pdo->prepare('DELETE FROM prestamos WHERE id = ?')->execute([$id]);
    $pdo->commit();
    flash('Préstamo eliminado.');
}
header('Location: index.php');