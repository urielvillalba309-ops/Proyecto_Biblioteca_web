<?php
require '../config/conexion.php';
try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $pdo->prepare('DELETE FROM categorias WHERE id = ?')->execute([(int)$_POST['id']]);
        flash('Categoría eliminada.');
    }
    header('Location: index.php');
} catch (PDOException $e) {
    header('Location: index.php?error=1');
}