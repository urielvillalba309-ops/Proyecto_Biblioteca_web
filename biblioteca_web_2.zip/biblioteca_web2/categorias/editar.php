<?php
$base = '../';
require '../config/conexion.php';
$id = (int)($_GET['id'] ?? 0);
$st = $pdo->prepare('SELECT * FROM categorias WHERE id = ?');
$st->execute([$id]);
$c = $st->fetch();
if (!$c) { header('Location: index.php'); exit; }
$nombre = $c['nombre'];
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    if ($nombre === '') {
        $err = 'Escribí el nombre de la categoría.';
    } else {
        $st = $pdo->prepare('SELECT COUNT(*) FROM categorias WHERE nombre = ? AND id <> ?');
        $st->execute([$nombre, $id]);
        if ($st->fetchColumn()) {
            $err = 'Ya existe otra categoría con ese nombre.';
        } else {
            $pdo->prepare('UPDATE categorias SET nombre = ? WHERE id = ?')->execute([$nombre, $id]);
            flash('Categoría actualizada correctamente.');
            header('Location: index.php');
            exit;
        }
    }
}
include '../includes/header.php';
?>
<h2>Editar categoría</h2>
<?php if ($err): ?><p class="msg error"><?= e($err) ?></p><?php endif; ?>
<form method="post" class="form">
  <label>Nombre <input name="nombre" value="<?= e($nombre) ?>" required></label>
  <button>Guardar</button> <a href="index.php">Cancelar</a>
</form>
<?php include '../includes/footer.php'; ?>