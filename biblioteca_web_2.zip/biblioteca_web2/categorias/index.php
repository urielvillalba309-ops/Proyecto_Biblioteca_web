<?php
$base = '../';
require '../config/conexion.php';
$cats = $pdo->query('SELECT c.id, c.nombre, COUNT(l.id) AS total
    FROM categorias c LEFT JOIN libros l ON l.id_categoria = c.id
    GROUP BY c.id, c.nombre ORDER BY c.nombre')->fetchAll();
include '../includes/header.php';
?>
<h2>Categorías</h2>
<?php if (isset($_GET['error'])): ?><p class="msg error">No se puede eliminar: la categoría tiene libros asociados.</p><?php endif; ?>
<div class="barra">
  <span></span>
  <a class="btn" href="crear.php">+ Nueva categoría</a>
</div>
<table>
  <tr><th>Nombre</th><th>Libros</th><th></th></tr>
  <?php foreach ($cats as $c): ?>
  <tr>
    <td><?= e($c['nombre']) ?></td><td><?= e($c['total']) ?></td>
    <td class="acc">
      <a class="btn sm" href="editar.php?id=<?= $c['id'] ?>">Editar</a>
      <form method="post" action="eliminar.php" onsubmit="return confirm('¿Eliminar esta categoría?')">
        <input type="hidden" name="id" value="<?= $c['id'] ?>"><button class="sm rojo">Eliminar</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
<?php include '../includes/footer.php'; ?>