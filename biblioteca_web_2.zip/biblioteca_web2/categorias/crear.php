<?php
$base = '../';
require '../config/conexion.php';
$nombre = '';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    if ($nombre === '') {
        $err = 'Escribí el nombre de la categoría.';
    } else {
        $st = $pdo->prepare('SELECT COUNT(*) FROM categorias WHERE nombre = ?');
        $st->execute([$nombre]);
        if ($st->fetchColumn()) {
            $err = 'Esa categoría ya existe.';
        } else {
            $pdo->prepare('INSERT INTO categorias (nombre) VALUES (?)')->execute([$nombre]);
            flash('Categoría agregada correctamente.');
            header('Location: index.php');
            exit;
        }
    }
}
include '../includes/header.php';
?>
<h2>Nueva categoría</h2>
<?php if ($err): ?><p class="msg error"><?= e($err) ?></p><?php endif; ?>
<form method="post" class="form">
  <label>Nombre <input name="nombre" value="<?= e($nombre) ?>" required></label>
  <button>Guardar</button> <a href="index.php">Cancelar</a>
</form>
<?php include '../includes/footer.php'; ?>