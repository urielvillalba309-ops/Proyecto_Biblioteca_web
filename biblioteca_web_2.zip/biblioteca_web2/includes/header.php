<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$es_admin   = ($_SESSION['rol'] ?? '') === 'admin';
$es_cliente = ($_SESSION['rol'] ?? '') === 'cliente';
$pendientes = 0;
if ($es_admin && isset($pdo)) {
    $pendientes = (int)$pdo->query("SELECT COUNT(*) FROM solicitudes WHERE estado = 'pendiente'")->fetchColumn();
}

// detecta en qué módulo estamos para marcar el menú
$dir = basename(dirname($_SERVER['SCRIPT_NAME']));
$sec = in_array($dir, ['libros', 'socios', 'prestamos', 'categorias', 'solicitudes']) ? $dir : 'inicio';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Biblioteca Web2</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= $base ?>css/estilos.css">
</head>
<body>
<div class="layout">
  <aside class="sidebar">
    <div class="logo">📚 Biblioteca <span>Web2</span></div>
    <nav>
      <?php if ($es_admin): ?>
      <a href="<?= $base ?>index.php" class="<?= $sec === 'inicio' ? 'activo' : '' ?>">🏠 Inicio</a>
      <?php endif; ?>
      <a href="<?= $base ?>libros/index.php" class="<?= $sec === 'libros' ? 'activo' : '' ?>">📖 Libros</a>
     <?php if ($es_cliente): ?>
      <a href="<?= $base ?>solicitudes/mis.php" class="<?= $sec === 'solicitudes' ? 'activo' : '' ?>">📝 Mis solicitudes</a>
      <?php endif; ?>
      <?php if ($es_admin): ?>
      <a href="<?= $base ?>socios/index.php" class="<?= $sec === 'socios' ? 'activo' : '' ?>">👥 Socios</a>
      <a href="<?= $base ?>categorias/index.php" class="<?= $sec === 'categorias' ? 'activo' : '' ?>">🏷️ Categorías</a>
      <a href="<?= $base ?>prestamos/index.php" class="<?= $sec === 'prestamos' ? 'activo' : '' ?>">🔄 Préstamos</a>
      <a href="<?= $base ?>solicitudes/index.php" class="<?= $sec === 'solicitudes' ? 'activo' : '' ?>">📨 Solicitudes<?php if ($pendientes): ?> <span class="contador"><?= $pendientes ?></span><?php endif; ?></a>
      <?php endif; ?>
    </nav>
    <div class="usuario">
      <?php if ($es_admin || $es_cliente): ?>
        <span>👤 <?= e($_SESSION['usuario']) ?></span>
        <a href="<?= $base ?>logout.php">Salir</a>
      <?php else: ?>
        <a href="<?= $base ?>login.php">🔑 Ingresar</a>
      <?php endif; ?>
    </div>
  </aside>
  <div class="contenido">
  <main>
<?php mostrar_flash(); ?>