<?php
$solo_cliente = true;
$base = '../';
require '../config/conexion.php';
$st = $pdo->prepare('SELECT sol.*, l.titulo, l.autor FROM solicitudes sol
    JOIN libros l ON l.id = sol.id_libro
    WHERE sol.id_socio = ? ORDER BY sol.id DESC');
$st->execute([(int)($_SESSION['id_socio'] ?? 0)]);
$solicitudes = $st->fetchAll();
$badges = ['pendiente' => ['warn', 'Pendiente'], 'aprobada' => ['ok', 'Aprobada'], 'rechazada' => ['pend', 'Rechazada']];
include '../includes/header.php';
?>
<h2>Mis solicitudes</h2>
<table>
  <tr><th>Libro</th><th>Autor</th><th>Fecha</th><th>Estado</th></tr>
  <?php foreach ($solicitudes as $s): ?>
  <tr>
    <td><?= e($s['titulo']) ?></td><td><?= e($s['autor']) ?></td><td><?= e($s['fecha_solicitud']) ?></td>
    <td><span class="<?= $badges[$s['estado']][0] ?>"><?= $badges[$s['estado']][1] ?></span></td>
  </tr>
  <?php endforeach; ?>
  <?php if (!$solicitudes): ?><tr><td colspan="4">Todavía no hiciste ninguna solicitud.</td></tr><?php endif; ?>
</table>
<?php include '../includes/footer.php'; ?>