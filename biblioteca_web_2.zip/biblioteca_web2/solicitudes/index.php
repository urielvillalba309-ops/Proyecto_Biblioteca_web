<?php
$base = '../';
require '../config/conexion.php'; // sin bandera: solo admin
$solicitudes = $pdo->query("SELECT sol.*, l.titulo, l.stock, s.nombre AS socio
    FROM solicitudes sol
    JOIN libros l ON l.id = sol.id_libro
    JOIN socios s ON s.id = sol.id_socio
    ORDER BY sol.estado = 'pendiente' DESC, sol.id DESC")->fetchAll();
$badges = ['pendiente' => ['warn', 'Pendiente'], 'aprobada' => ['ok', 'Aprobada'], 'rechazada' => ['pend', 'Rechazada']];
include '../includes/header.php';
?>
<h2>Solicitudes</h2>
<table>
  <tr><th>Libro</th><th>Socio</th><th>Fecha</th><th>Stock</th><th>Estado</th><th></th></tr>
  <?php foreach ($solicitudes as $sol): ?>
  <tr>
    <td><?= e($sol['titulo']) ?></td><td><?= e($sol['socio']) ?></td>
    <td><?= e($sol['fecha_solicitud']) ?></td><td><?= e($sol['stock']) ?></td>
    <td><span class="<?= $badges[$sol['estado']][0] ?>"><?= $badges[$sol['estado']][1] ?></span></td>
    <td class="acc">
      <?php if ($sol['estado'] === 'pendiente'): ?>
      <form method="post" action="aprobar.php" onsubmit="return confirm('¿Aprobar y registrar el préstamo?')">
        <input type="hidden" name="id" value="<?= $sol['id'] ?>"><button class="sm verde">Aprobar</button>
      </form>
      <form method="post" action="rechazar.php" onsubmit="return confirm('¿Rechazar esta solicitud?')">
        <input type="hidden" name="id" value="<?= $sol['id'] ?>"><button class="sm rojo">Rechazar</button>
      </form>
      <?php endif; ?>
    </td>
  </tr>
  <?php endforeach; ?>
  <?php if (!$solicitudes): ?><tr><td colspan="6">No hay solicitudes todavía.</td></tr><?php endif; ?>
</table>
<?php include '../includes/footer.php'; ?>