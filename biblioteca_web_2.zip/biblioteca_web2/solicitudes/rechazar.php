<?php
require '../config/conexion.php'; // solo admin
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $u = $pdo->prepare("UPDATE solicitudes SET estado = 'rechazada' WHERE id = ? AND estado = 'pendiente'");
    $u->execute([$id]);
    flash($u->rowCount() ? 'Solicitud rechazada.' : 'Esa solicitud ya no está pendiente.', $u->rowCount() ? 'exito' : 'error');
}
header('Location: index.php');