<?php
$solo_cliente = true; // solo entran clientes
require '../config/conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_libro = (int)($_POST['id_libro'] ?? 0);
    $id_socio = (int)($_SESSION['id_socio'] ?? 0);

    $st = $pdo->prepare('SELECT stock FROM libros WHERE id = ?');
    $st->execute([$id_libro]);
    $libro = $st->fetch();

    if (!$id_socio) {
        flash('Tu cuenta no está vinculada a un socio.', 'error');
    } elseif (!$libro || $libro['stock'] < 1) {
        flash('Ese libro no está disponible.', 'error');
    } else {
        $st = $pdo->prepare("SELECT COUNT(*) FROM solicitudes WHERE id_libro = ? AND id_socio = ? AND estado = 'pendiente'");
        $st->execute([$id_libro, $id_socio]);
        if ($st->fetchColumn()) {
            flash('Ya tenés una solicitud pendiente para ese libro.', 'error');
        } else {
            $pdo->prepare('INSERT INTO solicitudes (id_libro, id_socio, fecha_solicitud) VALUES (?,?,CURDATE())')
                ->execute([$id_libro, $id_socio]);
            flash('Solicitud enviada. El bibliotecario la va a revisar.');
        }
    }
}
header('Location: mis.php');