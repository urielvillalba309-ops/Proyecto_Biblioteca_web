<?php
require '../config/conexion.php'; // solo admin
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $pdo->beginTransaction();

    $st = $pdo->prepare("SELECT * FROM solicitudes WHERE id = ? AND estado = 'pendiente' FOR UPDATE");
    $st->execute([$id]);
    $sol = $st->fetch();

    if (!$sol) {
        $pdo->rollBack();
        flash('Esa solicitud ya no está pendiente.', 'error');
    } else {
        $u = $pdo->prepare('UPDATE libros SET stock = stock - 1 WHERE id = ? AND stock > 0');
        $u->execute([$sol['id_libro']]);
        if (!$u->rowCount()) {
            $pdo->rollBack();
            flash('No se puede aprobar: el libro no tiene stock.', 'error');
        } else {
            $pdo->prepare('INSERT INTO prestamos (id_libro, id_socio, fecha_prestamo) VALUES (?,?,CURDATE())')
                ->execute([$sol['id_libro'], $sol['id_socio']]);
            $pdo->prepare("UPDATE solicitudes SET estado = 'aprobada' WHERE id = ?")->execute([$id]);
            $pdo->commit();
            flash('Solicitud aprobada. Se registró el préstamo.');
        }
    }
}
header('Location: index.php');