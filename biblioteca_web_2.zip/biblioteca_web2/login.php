<?php
$publica = true; // esta página no pide login (si no, nunca podrías entrar)
require 'config/conexion.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// si ya estás logueado, te mando a tu pantalla
if (!empty($_SESSION['rol'])) {
    header('Location: ' . ($_SESSION['rol'] === 'admin' ? 'index.php' : 'libros/index.php'));
    exit;
}

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $st = $pdo->prepare('SELECT * FROM usuarios WHERE usuario = ?');
    $st->execute([trim($_POST['usuario'] ?? '')]);
    $u = $st->fetch();

    if ($u && password_verify($_POST['clave'] ?? '', $u['clave'])) {
        session_regenerate_id(true);
        $_SESSION['usuario']  = $u['usuario'];
        $_SESSION['rol']      = $u['rol'];
        $_SESSION['id_socio'] = $u['id_socio'];
        header('Location: ' . ($u['rol'] === 'admin' ? 'index.php' : 'libros/index.php'));
        exit;
    }
    $err = 'Usuario o clave incorrectos.';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Ingresar · Biblioteca Web2</title>
<link rel="stylesheet" href="css/estilos.css">
</head>
<body>
<div class="login-box">
  <h1>📚 Biblioteca Web2</h1>
  <p>Ingresá con tu usuario</p>
  <?php if ($err): ?><p class="msg error"><?= e($err) ?></p><?php endif; ?>
  <form method="post" class="form" style="box-shadow:none;padding:0">
    <label>Usuario <input name="usuario" required autofocus></label>
    <label>Clave <input type="password" name="clave" required></label>
    <button>Ingresar</button>
  </form>
  <p style="margin-top:16px"><a href="libros/index.php">← Ver catálogo</a></p>
</div>
</body>
</html>