<?php
$publica = true; // el listado de libros lo puede ver cualquiera
$base = '../';
require '../config/conexion.php';
$es_admin   = ($_SESSION['rol'] ?? '') === 'admin';
$es_cliente = ($_SESSION['rol'] ?? '') === 'cliente';
$q = trim($_GET['q'] ?? '');
$st = $pdo->prepare('SELECT l.*, c.nombre AS categoria FROM libros l JOIN categorias c ON c.id = l.id_categoria WHERE l.titulo LIKE ? OR l.autor LIKE ? ORDER BY l.titulo');
$st->execute(["%$q%", "%$q%"]);
$libros = $st->fetchAll();
include '../includes/header.php';
?>
<h2>Libros</h2>
<?php if (isset($_GET['error'])): ?><p class="msg error">No se puede eliminar: el libro tiene préstamos asociados.</p><?php endif; ?>

<?php if (!$es_admin && !$es_cliente): ?>
<p class="msg info">Para solicitar un libro, <a href="../login.php">ingresá con tu cuenta de socio</a>.</p>
<?php endif; ?>

<div class="barra">
  <form method="get"><input name="q" placeholder="Buscar título o autor" value="<?= e($q) ?>"><button>Buscar</button></form>
  <?php if ($es_admin): ?><a class="btn" href="crear.php">+ Nuevo libro</a><?php endif; ?>
</div>

<div class="catalogo">
  <?php foreach ($libros as $l): ?>
  <article class="libro">
    <div class="portada p<?= $l['id_categoria'] % 6 ?>"><?= e(mb_strtoupper(mb_substr($l['titulo'], 0, 1))) ?></div>
    <div class="libro-info">
      <span class="chip"><?= e($l['categoria']) ?></span>
      <h3><?= e($l['titulo']) ?></h3>
      <p class="autor"><?= e($l['autor']) ?><?= $l['anio'] ? ' · ' . e($l['anio']) : '' ?></p>
      <div class="libro-pie">
        <span>
          <?= $l['stock'] > 0 ? '<span class="ok">Disponible</span>' : '<span class="pend">No disponible</span>' ?>
          <?= $es_admin ? '<small>(' . e($l['stock']) . ')</small>' : '' ?>
        </span>

        <?php if ($es_admin): ?>
        <div class="acc">
          <a class="btn sm" href="editar.php?id=<?= $l['id'] ?>">Editar</a>
          <form method="post" action="eliminar.php" onsubmit="return confirm('¿Eliminar este libro?')">
            <input type="hidden" name="id" value="<?= $l['id'] ?>"><button class="sm rojo">Eliminar</button>
          </form>
        </div>
        <?php endif; ?>

        <?php if ($es_cliente && $l['stock'] > 0): ?>
        <form method="post" action="../solicitudes/crear.php">
          <input type="hidden" name="id_libro" value="<?= $l['id'] ?>"><button class="sm">Solicitar</button>
        </form>
        <?php endif; ?>
      </div>
    </div>
  </article>
  <?php endforeach; ?>
</div>
<?php if (!$libros): ?><p class="msg info">No se encontraron libros.</p><?php endif; ?>
<?php include '../includes/footer.php'; ?>