<?php if ($err): ?><p class="msg error"><?= e($err) ?></p><?php endif; ?>
<form method="post" class="form">
  <label>Título <input name="titulo" value="<?= e($l['titulo']) ?>" required></label>
  <label>Autor <input name="autor" value="<?= e($l['autor']) ?>" required></label>
  <label>Categoría
    <select name="id_categoria" required>
      <option value="">Elegí...</option>
      <?php foreach ($cats as $c): ?>
      <option value="<?= $c['id'] ?>" <?= $c['id'] == $l['id_categoria'] ? 'selected' : '' ?>><?= e($c['nombre']) ?></option>
      <?php endforeach; ?>
    </select>
  </label>
  <label>Año <input type="number" name="anio" value="<?= e($l['anio']) ?>"></label>
  <label>Stock <input type="number" name="stock" min="0" value="<?= e($l['stock']) ?>" required></label>
  <button>Guardar</button> <a href="index.php">Cancelar</a>
</form>
