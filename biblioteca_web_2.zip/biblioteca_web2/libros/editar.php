<?php
$base = '../';
require '../config/conexion.php';
$id = (int)($_GET['id'] ?? 0);
$st = $pdo->prepare('SELECT * FROM libros WHERE id = ?');
$st->execute([$id]);
$l = $st->fetch();
if (!$l) { header('Location: index.php'); exit; }
$cats = $pdo->query('SELECT * FROM categorias ORDER BY nombre')->fetchAll();
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $l = array_merge($l, $_POST);
    if (trim($l['titulo']) === '' || trim($l['autor']) === '' || !$l['id_categoria']) {
        $err = 'Completá título, autor y categoría.';
    } else {
        $pdo->prepare('UPDATE libros SET titulo=?, autor=?, id_categoria=?, anio=?, stock=? WHERE id=?')
            ->execute([trim($l['titulo']), trim($l['autor']), (int)$l['id_categoria'], $l['anio'] ?: null, (int)$l['stock'], $id]);
            flash('Libro actualizado correctamente.');
            header('Location: index.php');
        exit;
    }
}
include '../includes/header.php';
?>
<h2>Editar libro</h2>
<?php include 'form.php'; ?>
<?php include '../includes/footer.php'; ?>
