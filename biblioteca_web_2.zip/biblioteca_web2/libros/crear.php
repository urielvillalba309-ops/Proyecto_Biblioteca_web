<?php
$base = '../';
require '../config/conexion.php';
$cats = $pdo->query('SELECT * FROM categorias ORDER BY nombre')->fetchAll();
$l = ['titulo' => '', 'autor' => '', 'id_categoria' => '', 'anio' => '', 'stock' => 1];
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $l = array_merge($l, $_POST);
    if (trim($l['titulo']) === '' || trim($l['autor']) === '' || !$l['id_categoria']) {
        $err = 'Completá título, autor y categoría.';
    } else {
        $pdo->prepare('INSERT INTO libros (titulo, autor, id_categoria, anio, stock) VALUES (?,?,?,?,?)')
            ->execute([trim($l['titulo']), trim($l['autor']), (int)$l['id_categoria'], $l['anio'] ?: null, (int)$l['stock']]);
            flash('Libro agregado correctamente.');
            header('Location: index.php');
        exit;
    }
}
include '../includes/header.php';
?>
<h2>Nuevo libro</h2>
<?php include 'form.php'; ?>
<?php include '../includes/footer.php'; ?>
